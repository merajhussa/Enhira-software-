# ENHIRA Employee Attendance Management System

Android app (Kotlin + XML, ViewBinding) on a Firebase backend (Auth, Firestore, Cloud Functions).
All attendance decisions (geofence, QR, duplicates, timestamps, corrections) run on the server.

```
android/        Kotlin/XML app (package com.enhira.attendance)
functions/      Cloud Functions + dependency-free core logic (lib/) with unit tests (test/)
firebase/       Firestore security rules and indexes
firebase.json   Firebase project config + emulator ports
```

## Status (milestone 1 of 4)

| Module | State |
|---|---|
| Data model (all 17 tables as collections), security rules, indexes | Done |
| Auth: register (pending), email verification, login, reset, role routing, admin creation | Done |
| Registration approval/rejection, employee ID assignment | Done |
| Geofence (Haversine), spoof checks, rotating QR, Wi-Fi policy, check-in/out, audit log | Done, core logic unit-tested |
| Attendance corrections (request/approve/direct, history preserved) | Done (functions); admin UI pending |
| Employee dashboard (check in/out, distance/accuracy, month stats, notifications) | Done |
| Admin dashboard (today stats, approvals, QR kiosk, suspicious attempts) | Done (basic) |
| Employee CRUD screens, departments/designations/shifts/holidays/settings screens | Next |
| Leave management, charts, reports (XLSX/PDF/CSV), announcements, backup/restore | Later milestones |
| Login by employee ID, mobile OTP verification | Not started |

## What has and has not been verified

- `cd functions && node --test "test/*.test.js"` runs 13 tests: Haversine, inside/outside radius, mock location,
  bad/null-island coordinates, low accuracy, stale fixes, impossible travel, QR valid/expired/tampered/wrong office,
  late/early/overtime/half-day maths. They pass.
- The Android app and Cloud Functions entry points were **not compiled or run** (no Android SDK or npm access in the build sandbox).
  XML is well-formed and view-binding ids were cross-checked, but expect a few compile fixes on first build.
- Firestore rules and the Cloud Functions have not been exercised against the emulator yet.

## Setup

1. Create a Firebase project (Blaze plan is required for Cloud Functions). Enable **Authentication > Email/Password**
   and **Firestore** (region `asia-south1` recommended, matching the functions region).
2. Register an Android app with package `com.enhira.attendance`, download `google-services.json` into `android/app/`.
3. Deploy backend:
   ```
   npm i -g firebase-tools && firebase login
   cd functions && npm install && npm test
   cd .. && firebase deploy --only functions,firestore:rules,firestore:indexes
   ```
4. Create the first super admin (needs Application Default Credentials: `gcloud auth application-default login`):
   ```
   cd functions && node scripts/bootstrap-admin.js you@company.com "Your Name" "a-long-password"
   ```
5. In the Firebase console set the office coordinates on `officeLocations/hq`: `lat`, `lng`, `radiusM` (e.g. 100) and `active: true`.
   (An admin settings screen for this is in the next milestone.)
6. Open `android/` in Android Studio, sync, run. Sign in as the admin, create a kiosk admin with role `kiosk` (callable `createAdmin`)
   for the office tablet, and open **Show office QR** on it.
7. Employees: Create account, verify email, wait for approval (Admin > Pending registrations > Approve), sign in.

### Build the APK on GitHub (no Android Studio needed)

1. Push this folder to a GitHub repo (branch `main`).
2. Encode your Firebase file: `base64 -w0 android/app/google-services.json` (Mac: `base64 -i android/app/google-services.json`).
3. Repo > Settings > Secrets and variables > Actions > New secret: name `GOOGLE_SERVICES_JSON`, value = that text.
4. Repo > Actions > **Build Enhira APK** > Run workflow (it also runs on every push to `main`).
5. When it finishes, open the run and download the `enhira-debug-apk` artifact (zip containing `app-debug.apk`), then install it on your phone.

This produces a debug-signed APK for testing. A Play Store release needs a signed release build (separate keystore secret).

Local testing: `firebase emulators:start --only auth,firestore,functions` (point the app at the emulator before use).

## Verification policy

`companySettings/main.verificationPolicy` and the mirrored `companySettings/public`:
`GPS_ONLY`, `GPS_QR` (default), `GPS_WIFI`. Wi-Fi needs `allowedBssids` in `main`; Android may not expose the BSSID on every device.

## Known limits

- GPS and QR can still be defeated by a colluding employee photographing/forwarding the live QR within its 30–60 s window.
  Rotate secrets (`rotateOfficeQrSecret`) after any incident; consider device attestation (Play Integrity) as a later hardening step.
- Overnight shifts are not supported. Absent/percentage figures ignore public holidays until the holiday module lands.
- Demo data is intentionally not included; production bootstrap only creates the admin, one inactive office and settings.
