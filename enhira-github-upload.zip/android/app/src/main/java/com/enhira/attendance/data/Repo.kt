package com.enhira.attendance.data

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.functions.FirebaseFunctions
import com.google.firebase.functions.FirebaseFunctionsException
import kotlinx.coroutines.tasks.await

/** Single entry point to Firebase. All attendance decisions are made by Cloud Functions. */
object Repo {
    val auth: FirebaseAuth get() = FirebaseAuth.getInstance()
    val db: FirebaseFirestore get() = FirebaseFirestore.getInstance()
    private val functions: FirebaseFunctions get() = FirebaseFunctions.getInstance("asia-south1")

    val uid: String? get() = auth.currentUser?.uid

    @Suppress("UNCHECKED_CAST")
    suspend fun call(name: String, data: Map<String, Any?> = emptyMap()): Map<String, Any?> {
        val result = functions.getHttpsCallable(name).call(data).await()
        return (result.data as? Map<String, Any?>) ?: emptyMap()
    }

    /** "admin", "employee" or null (pending / unknown). Forces a token refresh so approvals apply immediately. */
    suspend fun role(): String? {
        val token = auth.currentUser?.getIdToken(true)?.await() ?: return null
        return token.claims["role"] as? String
    }

    fun signOut() = auth.signOut()
}

/** Turns SDK exceptions into messages that are safe and useful to show. */
fun Throwable.friendly(): String = when (this) {
    is FirebaseFunctionsException -> when (code) {
        FirebaseFunctionsException.Code.UNAUTHENTICATED -> "Please sign in again."
        FirebaseFunctionsException.Code.UNAVAILABLE -> "No connection to the server. Check your internet."
        else -> message ?: "Request failed."
    }
    is com.google.firebase.auth.FirebaseAuthInvalidCredentialsException,
    is com.google.firebase.auth.FirebaseAuthInvalidUserException -> "Incorrect email or password."
    is com.google.firebase.auth.FirebaseAuthUserCollisionException -> "An account with this email already exists."
    is com.google.firebase.FirebaseNetworkException -> "No internet connection."
    else -> message ?: "Something went wrong."
}
