package com.enhira.attendance.ui

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.EditText
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.enhira.attendance.data.Repo
import com.enhira.attendance.data.friendly
import com.enhira.attendance.databinding.ActivityAdminHomeBinding
import com.enhira.attendance.databinding.ItemPendingBinding
import com.enhira.attendance.util.Dates
import com.enhira.attendance.util.set
import com.enhira.attendance.util.show
import com.google.firebase.firestore.AggregateSource
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.Query
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

class AdminHomeActivity : AppCompatActivity() {
    private lateinit var b: ActivityAdminHomeBinding
    private val pending = mutableListOf<DocumentSnapshot>()
    private val adapter = PendingAdapter(pending, ::approve, ::reject)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityAdminHomeBinding.inflate(layoutInflater)
        setContentView(b.root)

        listOf(b.statTotal to "Employees", b.statPresent to "Present", b.statAbsent to "Absent",
            b.statLate to "Late arrivals", b.statWorking to "Working now", b.statPercent to "Attendance")
            .forEach { (s, l) -> s.set(l, "–") }

        b.rvPending.layoutManager = LinearLayoutManager(this)
        b.rvPending.adapter = adapter
        b.refresh.setOnRefreshListener { load() }
        b.btnShowQr.setOnClickListener { pickOffice { id -> startActivity(Intent(this, QrDisplayActivity::class.java).putExtra("officeId", id)) } }
        b.btnLogout.setOnClickListener {
            Repo.signOut()
            startActivity(Intent(this, LoginActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK))
        }
        load()
    }

    private fun load() {
        val uid = Repo.uid ?: return
        lifecycleScope.launch {
            runCatching { Repo.db.document("admins/$uid").get().await() }.getOrNull()?.let {
                b.tvAdminName.text = it.getString("name") ?: ""
                b.tvAdminRole.text = (it.getString("adminRole") ?: "").replace('_', ' ')
            }
            loadStats(); loadPending(); loadSuspicious()
            b.refresh.isRefreshing = false
        }
    }

    private suspend fun loadStats() {
        runCatching {
            val total = Repo.db.collection("employees").whereEqualTo("status", "approved")
                .count().get(AggregateSource.SERVER).await().count
            val rows = Repo.db.collection("attendance").whereEqualTo("date", Dates.today()).get().await().documents
            val present = rows.count { it.get("checkInAt") != null }
            val late = rows.count { it.getString("status") == "Late" || (it.getLong("lateMinutes") ?: 0L) > 0L }
            val working = rows.count { it.get("checkInAt") != null && it.get("checkOutAt") == null }
            // Absent excludes nobody on leave yet: leave and holiday modules will refine this.
            b.statTotal.set("Employees", total.toString()); b.statPresent.set("Present", present.toString())
            b.statAbsent.set("Absent", (total - present).coerceAtLeast(0).toString()); b.statLate.set("Late arrivals", late.toString())
            b.statWorking.set("Working now", working.toString())
            b.statPercent.set("Attendance", if (total == 0L) "–" else "${Math.round(present * 100.0 / total)}%")
        }
    }

    private suspend fun loadPending() {
        val snap = runCatching {
            Repo.db.collection("employees").whereEqualTo("status", "pending")
                .orderBy("createdAt", Query.Direction.DESCENDING).limit(50).get().await()
        }.getOrNull()
        pending.clear(); snap?.documents?.let { pending.addAll(it) }
        adapter.notifyDataSetChanged()
        b.tvNoPending.show(pending.isEmpty())
    }

    private suspend fun loadSuspicious() {
        val snap = runCatching {
            Repo.db.collection("auditLogs").whereEqualTo("severity", "suspicious")
                .orderBy("at", Query.Direction.DESCENDING).limit(5).get().await()
        }.getOrNull()
        b.tvSuspicious.text = when {
            snap == null -> "Not available for your role."
            snap.isEmpty -> "None recorded."
            else -> snap.documents.joinToString("\n") {
                val d = it.get("details") as? Map<*, *>
                "${d?.get("employeeId") ?: "?"} – ${d?.get("code") ?: it.getString("action")}"
            }
        }
    }

    // ---------- actions ----------
    private fun pickOffice(onPick: (String) -> Unit) {
        lifecycleScope.launch {
            val offices = runCatching { Repo.db.collection("officeLocations").get().await().documents }.getOrNull().orEmpty()
            if (offices.isEmpty()) { AlertDialog.Builder(this@AdminHomeActivity).setMessage("No office is configured yet.").setPositiveButton("OK", null).show(); return@launch }
            if (offices.size == 1) { onPick(offices[0].id); return@launch }
            AlertDialog.Builder(this@AdminHomeActivity).setTitle("Select office")
                .setItems(offices.map { it.getString("name") ?: it.id }.toTypedArray()) { _, i -> onPick(offices[i].id) }.show()
        }
    }

    private fun approve(doc: DocumentSnapshot) = pickOffice { officeId ->
        lifecycleScope.launch {
            try {
                val r = Repo.call("reviewRegistration", mapOf("uid" to doc.id, "decision" to "approve", "officeId" to officeId, "weeklyOff" to listOf("Sunday")))
                AlertDialog.Builder(this@AdminHomeActivity).setMessage("Approved. Employee ID: ${r["employeeId"]}").setPositiveButton("OK", null).show()
                load()
            } catch (e: Exception) {
                AlertDialog.Builder(this@AdminHomeActivity).setMessage(e.friendly()).setPositiveButton("OK", null).show()
            }
        }
    }

    private fun reject(doc: DocumentSnapshot) {
        val input = EditText(this).apply { hint = "Reason (shown to the employee)" }
        AlertDialog.Builder(this).setTitle("Reject registration").setView(input)
            .setPositiveButton("Reject") { _, _ ->
                lifecycleScope.launch {
                    try {
                        Repo.call("reviewRegistration", mapOf("uid" to doc.id, "decision" to "reject", "reason" to input.text.toString().ifBlank { "Not specified" }))
                        load()
                    } catch (e: Exception) {
                        AlertDialog.Builder(this@AdminHomeActivity).setMessage(e.friendly()).setPositiveButton("OK", null).show()
                    }
                }
            }.setNegativeButton("Cancel", null).show()
    }
}

private class PendingAdapter(
    private val items: List<DocumentSnapshot>,
    private val onApprove: (DocumentSnapshot) -> Unit,
    private val onReject: (DocumentSnapshot) -> Unit,
) : RecyclerView.Adapter<PendingAdapter.VH>() {
    class VH(val b: ItemPendingBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemPendingBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, position: Int) {
        val d = items[position]
        h.b.tvName.text = d.getString("name")
        h.b.tvInfo.text = "${d.getString("email")}  •  ${d.getString("phone")}"
        h.b.btnApprove.setOnClickListener { onApprove(d) }
        h.b.btnReject.setOnClickListener { onReject(d) }
    }
}
