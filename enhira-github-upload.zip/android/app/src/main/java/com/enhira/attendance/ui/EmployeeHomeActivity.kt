package com.enhira.attendance.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.wifi.WifiManager
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.enhira.attendance.R
import com.enhira.attendance.data.Repo
import com.enhira.attendance.data.friendly
import com.enhira.attendance.databinding.ActivityEmployeeHomeBinding
import com.enhira.attendance.util.Dates
import com.enhira.attendance.util.LocationHelper
import com.enhira.attendance.util.set
import com.enhira.attendance.util.show
import com.google.firebase.firestore.Query
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.util.Calendar
import java.util.Locale

class EmployeeHomeActivity : AppCompatActivity() {
    private lateinit var b: ActivityEmployeeHomeBinding

    private var officeLat: Double? = null
    private var officeLng: Double? = null
    private var officeRadius = 100.0
    private var policy = "GPS_QR"
    private var requireQrOnCheckOut = true
    private var weeklyOff: List<String> = listOf("Sunday")
    private var today: Map<String, Any?>? = null
    private var pendingKind: String? = null

    private val permission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) { refreshGeo(); pendingKind?.let { start(it) } }
        else showResult(false, "Location permission is required to mark attendance.")
        if (!granted) pendingKind = null
    }

    private val scanner = registerForActivityResult(ScanContract()) { res ->
        val kind = pendingKind ?: return@registerForActivityResult
        val token = res.contents
        if (token.isNullOrEmpty()) { showResult(false, "QR scan cancelled."); pendingKind = null }
        else perform(kind, token)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityEmployeeHomeBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.statPresent.set("Present days", "–"); b.statAbsent.set("Absent days", "–")
        b.statLeave.set("Leave days", "–"); b.statLate.set("Late arrivals", "–")
        b.statHalf.set("Half days", "–"); b.statPercent.set("Attendance", "–")

        b.btnCheckIn.setOnClickListener { start("checkIn") }
        b.btnCheckOut.setOnClickListener { start("checkOut") }
        b.refresh.setOnRefreshListener { load() }
        b.btnLogout.setOnClickListener { confirmLogout() }
        b.btnNotifications.setOnClickListener { showNotifications() }
        load()
    }

    // ---------- data ----------
    private fun load() {
        val uid = Repo.uid ?: return
        lifecycleScope.launch {
            try {
                val emp = Repo.db.document("employees/$uid").get().await()
                b.tvName.text = emp.getString("name") ?: ""
                b.tvEmpId.text = "ID: ${emp.getString("employeeId") ?: "–"}"
                @Suppress("UNCHECKED_CAST")
                weeklyOff = (emp.get("weeklyOff") as? List<String>) ?: weeklyOff

                runCatching { Repo.db.document("companySettings/public").get().await() }.getOrNull()?.let {
                    policy = it.getString("verificationPolicy") ?: policy
                    requireQrOnCheckOut = it.getBoolean("requireQrOnCheckOut") ?: true
                }
                emp.getString("officeId")?.let { id ->
                    val o = Repo.db.document("officeLocations/$id").get().await()
                    officeLat = o.getDouble("lat"); officeLng = o.getDouble("lng")
                    officeRadius = o.getDouble("radiusM") ?: 100.0
                }

                val docs = Repo.db.collection("attendance").whereEqualTo("employeeUid", uid)
                    .orderBy("date", Query.Direction.DESCENDING).limit(62).get().await().documents.map { it.data ?: emptyMap() }
                today = docs.firstOrNull { it["date"] == Dates.today() }
                renderToday(); renderStats(docs)
                refreshGeo()
            } catch (e: Exception) {
                showResult(false, e.friendly())
            } finally { b.refresh.isRefreshing = false }
        }
    }

    private fun renderToday() {
        val t = today
        val inMs = (t?.get("checkInAt") as? com.google.firebase.Timestamp)?.toDate()?.time
        val outMs = (t?.get("checkOutAt") as? com.google.firebase.Timestamp)?.toDate()?.time
        b.tvToday.text = when {
            t == null -> "Not checked in"
            outMs != null -> (t["status"] as? String) ?: "Checked out"
            else -> "Working – ${(t["status"] as? String) ?: "Present"}"
        }
        b.tvTimes.text = if (t == null) "" else
            "In ${Dates.time(inMs)}   Out ${Dates.time(outMs)}   Worked ${Dates.hm((t["workedMinutes"] as? Number)?.toLong())}"
        b.btnCheckIn.isEnabled = inMs == null
        b.btnCheckOut.isEnabled = inMs != null && outMs == null
    }

    private fun renderStats(all: List<Map<String, Any?>>) {
        val cal = Calendar.getInstance()
        val prefix = String.format(Locale.US, "%04d-%02d-", cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1)
        val month = all.filter { (it["date"] as? String)?.startsWith(prefix) == true }
        val present = month.count { it["status"] in listOf("Present", "Late", "Early Leave", "Work From Home") }
        val half = month.count { it["status"] == "Half Day" }
        val leave = month.count { it["status"] == "On Leave" }
        val late = month.count { it["status"] == "Late" || ((it["lateMinutes"] as? Number)?.toInt() ?: 0) > 0 }

        // Working days elapsed this month, excluding the employee's weekly off. Public holidays are
        // not subtracted yet (holiday calendar module), so absent days/percentage are approximate.
        val names = listOf("Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday")
        val c = Calendar.getInstance().apply { set(Calendar.DAY_OF_MONTH, 1) }
        var elapsed = 0
        val todayDay = cal.get(Calendar.DAY_OF_MONTH)
        while (c.get(Calendar.DAY_OF_MONTH) <= todayDay && c.get(Calendar.MONTH) == cal.get(Calendar.MONTH)) {
            val isToday = c.get(Calendar.DAY_OF_MONTH) == todayDay
            val off = names[c.get(Calendar.DAY_OF_WEEK) - 1] in weeklyOff
            if (!off && (!isToday || today != null)) elapsed++
            c.add(Calendar.DAY_OF_MONTH, 1)
        }
        val absent = (elapsed - present - half - leave).coerceAtLeast(0)
        val pct = if (elapsed == 0) "–" else "${Math.round((present + half * 0.5) / elapsed * 100)}%"

        b.statPresent.set("Present days", present.toString()); b.statAbsent.set("Absent days", absent.toString())
        b.statLeave.set("Leave days", leave.toString()); b.statLate.set("Late arrivals", late.toString())
        b.statHalf.set("Half days", half.toString()); b.statPercent.set("Attendance", pct)
    }

    // ---------- location preview (informational; the server decides) ----------
    private fun hasLocationPermission() = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun refreshGeo() {
        val lat = officeLat; val lng = officeLng
        if (lat == null || lng == null) { b.tvGeoStatus.text = "Office location not configured"; b.tvGeoDetail.text = "Contact your administrator."; return }
        if (!hasLocationPermission()) { b.tvGeoStatus.text = "Location permission needed"; b.tvGeoDetail.text = "Tap Check In to grant it."; return }
        lifecycleScope.launch {
            val fix = runCatching { LocationHelper.freshFix(this@EmployeeHomeActivity) }.getOrNull()
            if (fix == null) { b.tvGeoStatus.text = "Location unavailable"; b.tvGeoDetail.text = "Turn on GPS and pull to refresh."; return@launch }
            val d = LocationHelper.haversineMeters(lat, lng, fix.lat, fix.lng)
            val inside = d <= officeRadius
            b.tvGeoStatus.text = if (inside) "Inside office area" else "Outside office area"
            b.tvGeoStatus.setTextColor(ContextCompat.getColor(this@EmployeeHomeActivity, if (inside) R.color.enhira_ok else R.color.enhira_error))
            b.tvGeoDetail.text = "Distance ${Math.round(d)} m (limit ${Math.round(officeRadius)} m)  •  GPS accuracy ±${Math.round(fix.accuracyM)} m" +
                if (fix.isMock) "  •  mock location detected" else ""
        }
    }

    // ---------- check in / out ----------
    private fun needsQr(kind: String) = policy == "GPS_QR" && (kind == "checkIn" || requireQrOnCheckOut)

    private fun start(kind: String) {
        pendingKind = kind
        if (!hasLocationPermission()) { permission.launch(Manifest.permission.ACCESS_FINE_LOCATION); return }
        if (needsQr(kind)) {
            scanner.launch(ScanOptions().setDesiredBarcodeFormats(ScanOptions.QR_CODE)
                .setPrompt("Scan the QR code shown at the office").setBeepEnabled(false).setOrientationLocked(false))
        } else perform(kind, null)
    }

    @Suppress("DEPRECATION")
    private fun wifiBssid(): String? = runCatching {
        (applicationContext.getSystemService(WIFI_SERVICE) as WifiManager).connectionInfo?.bssid
            ?.takeIf { it != "02:00:00:00:00:00" }
    }.getOrNull()

    private fun perform(kind: String, qrToken: String?) {
        pendingKind = null
        b.progress.show(true); b.btnCheckIn.isEnabled = false; b.btnCheckOut.isEnabled = false
        lifecycleScope.launch {
            try {
                // Fix is taken after the scan so it is fresh when the server checks its age.
                val fix = LocationHelper.freshFix(this@EmployeeHomeActivity)
                    ?: return@launch showResult(false, "Could not read your location. Turn on GPS and try again.")
                val data = mutableMapOf<String, Any?>("fix" to fix.toMap())
                qrToken?.let { data["qrToken"] = it }
                if (policy == "GPS_WIFI") wifiBssid()?.let { data["wifiBssid"] = it }

                val r = Repo.call(kind, data)
                val ok = r["ok"] == true
                val dist = (r["distanceM"] as? Number)?.toDouble()
                val acc = (r["accuracyM"] as? Number)?.toDouble()
                showResult(ok, buildString {
                    append(r["message"] as? String ?: if (ok) "Done." else "Not recorded.")
                    if (dist != null) append("\nDistance from office: ${Math.round(dist)} m")
                    if (acc != null) append("   GPS accuracy: ±${Math.round(acc)} m")
                })
            } catch (e: Exception) {
                showResult(false, e.friendly())
            } finally { b.progress.show(false); load() }
        }
    }

    private fun showResult(ok: Boolean, msg: String) {
        b.tvResult.text = msg
        b.tvResult.setTextColor(ContextCompat.getColor(this, if (ok) R.color.enhira_ok else R.color.enhira_error))
        b.tvResult.show(true)
    }

    // ---------- notifications & sign out ----------
    private fun showNotifications() {
        val uid = Repo.uid ?: return
        lifecycleScope.launch {
            val snap = runCatching {
                Repo.db.collection("notifications").whereEqualTo("uid", uid)
                    .orderBy("createdAt", Query.Direction.DESCENDING).limit(25).get().await()
            }.getOrNull()
            val items = snap?.documents.orEmpty()
            val text = if (items.isEmpty()) "No notifications yet." else
                items.joinToString("\n\n") { "${it.getString("title")}\n${it.getString("body")}" }
            AlertDialog.Builder(this@EmployeeHomeActivity).setTitle("Notifications").setMessage(text)
                .setPositiveButton("Close", null).show()
            items.filter { it.getBoolean("read") != true }.forEach { it.reference.update("read", true) }
        }
    }

    private fun confirmLogout() {
        AlertDialog.Builder(this).setTitle("Sign out?").setMessage("You will need to sign in again.")
            .setPositiveButton("Sign out") { _, _ ->
                Repo.signOut()
                startActivity(Intent(this, LoginActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK))
            }.setNegativeButton("Cancel", null).show()
    }
}
