package com.enhira.attendance.ui

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.enhira.attendance.data.Repo
import com.enhira.attendance.data.friendly
import com.enhira.attendance.databinding.ActivityLoginBinding
import com.enhira.attendance.util.error
import com.enhira.attendance.util.show
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

class LoginActivity : AppCompatActivity() {
    private lateinit var b: ActivityLoginBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.btnLogin.setOnClickListener { login() }
        b.tvRegister.setOnClickListener { startActivity(Intent(this, RegisterActivity::class.java)) }
        b.tvForgot.setOnClickListener { resetPassword() }
    }

    private fun busy(on: Boolean) { b.progress.show(on); b.btnLogin.isEnabled = !on }

    private fun login() {
        val email = b.etEmail.text.toString().trim()
        val pass = b.etPassword.text.toString()
        if (email.isEmpty() || pass.isEmpty()) { b.tvError.error("Enter your email and password."); return }
        b.tvError.error(null); busy(true)
        lifecycleScope.launch {
            try {
                Repo.auth.signInWithEmailAndPassword(email, pass).await()
                when (Repo.role()) {
                    "admin" -> go(AdminHomeActivity::class.java)
                    "employee" -> go(EmployeeHomeActivity::class.java)
                    else -> {
                        Repo.signOut()
                        b.tvError.error("Your account is awaiting administrator approval, or was not approved.")
                    }
                }
            } catch (e: Exception) {
                b.tvError.error(e.friendly())
            } finally { busy(false) }
        }
    }

    private fun resetPassword() {
        val email = b.etEmail.text.toString().trim()
        if (email.isEmpty()) { b.tvError.error("Enter your email above first."); return }
        lifecycleScope.launch {
            runCatching { Repo.auth.sendPasswordResetEmail(email).await() }
            // Same message whether or not the account exists (no account enumeration).
            Toast.makeText(this@LoginActivity, "If that email is registered, a reset link was sent.", Toast.LENGTH_LONG).show()
        }
    }

    private fun go(cls: Class<*>) {
        startActivity(Intent(this, cls).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK))
    }
}
