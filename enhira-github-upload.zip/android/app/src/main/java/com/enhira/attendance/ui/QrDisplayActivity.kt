package com.enhira.attendance.ui

import android.graphics.Bitmap
import android.graphics.Color
import android.os.Bundle
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.enhira.attendance.data.Repo
import com.enhira.attendance.data.friendly
import com.enhira.attendance.databinding.ActivityQrDisplayBinding
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Office kiosk screen. Shows a server-signed token that changes every window (default 30 s).
 * Run it on a tablet inside the office, signed in as an admin/kiosk account with qr.display.
 */
class QrDisplayActivity : AppCompatActivity() {
    private lateinit var b: ActivityQrDisplayBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityQrDisplayBinding.inflate(layoutInflater)
        setContentView(b.root)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val officeId = intent.getStringExtra("officeId") ?: run { finish(); return }
        b.tvOffice.text = officeId

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                while (true) {
                    var waitMs = 5000L
                    try {
                        val r = Repo.call("getOfficeQr", mapOf("officeId" to officeId))
                        val token = r["token"] as String
                        val expires = (r["expiresAtMs"] as Number).toLong()
                        val serverNow = (r["serverNowMs"] as Number).toLong()
                        b.ivQr.setImageBitmap(render(token))
                        b.tvStatus.text = "Refreshes automatically"
                        // Fetch the next code just after this window rolls over (server clock, not device clock).
                        // The previous window stays valid for scanning for one extra window (grace).
                        waitMs = (expires - serverNow + 500).coerceIn(1000, 31000)
                    } catch (e: Exception) {
                        b.tvStatus.text = e.friendly()
                    }
                    delay(waitMs)
                }
            }
        }
    }

    private fun render(text: String, size: Int = 720): Bitmap {
        val hints = mapOf(EncodeHintType.ERROR_CORRECTION to ErrorCorrectionLevel.M, EncodeHintType.MARGIN to 1)
        val m = QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, size, size, hints)
        val px = IntArray(size * size) { i -> if (m[i % size, i / size]) Color.BLACK else Color.WHITE }
        return Bitmap.createBitmap(px, size, size, Bitmap.Config.ARGB_8888)
    }
}
