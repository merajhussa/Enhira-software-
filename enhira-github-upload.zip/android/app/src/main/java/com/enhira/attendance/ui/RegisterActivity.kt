package com.enhira.attendance.ui

import android.os.Bundle
import android.util.Patterns
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.enhira.attendance.data.Repo
import com.enhira.attendance.data.friendly
import com.enhira.attendance.databinding.ActivityRegisterBinding
import com.enhira.attendance.util.error
import com.enhira.attendance.util.show
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

class RegisterActivity : AppCompatActivity() {
    private lateinit var b: ActivityRegisterBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(b.root)
        b.btnRegister.setOnClickListener { register() }
    }

    private fun register() {
        val name = b.etName.text.toString().trim()
        val email = b.etEmail.text.toString().trim()
        val phone = b.etPhone.text.toString().trim()
        val pass = b.etPassword.text.toString()
        when {
            name.length < 2 -> return b.tvError.error("Enter your full name.")
            !Patterns.EMAIL_ADDRESS.matcher(email).matches() -> return b.tvError.error("Enter a valid email.")
            !Regex("^[+0-9 ()-]{7,20}$").matches(phone) -> return b.tvError.error("Enter a valid mobile number.")
            pass.length < 10 -> return b.tvError.error("Password must be at least 10 characters.")
        }
        b.tvError.error(null); b.progress.show(true); b.btnRegister.isEnabled = false
        lifecycleScope.launch {
            try {
                val user = Repo.auth.createUserWithEmailAndPassword(email, pass).await().user!!
                try {
                    user.sendEmailVerification().await()
                    // Creates users/employees docs with status = pending. Clients cannot write these.
                    Repo.call("submitRegistration", mapOf("name" to name, "phone" to phone))
                } catch (e: Exception) {
                    runCatching { user.delete().await() } // don't leave a half-registered account behind
                    throw e
                }
                Repo.signOut()
                AlertDialog.Builder(this@RegisterActivity)
                    .setTitle("Registration submitted")
                    .setMessage("Verify your email using the link we sent. An administrator must approve your account before you can sign in.")
                    .setPositiveButton("OK") { _, _ -> finish() }
                    .setCancelable(false).show()
            } catch (e: Exception) {
                b.tvError.error(e.friendly())
            } finally { b.progress.show(false); b.btnRegister.isEnabled = true }
        }
    }
}
