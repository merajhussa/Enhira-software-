package com.enhira.attendance.ui

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.enhira.attendance.data.Repo
import kotlinx.coroutines.launch

/** Routes by the server-issued role claim, never by anything stored on the device. */
class SplashActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        lifecycleScope.launch {
            val target = if (Repo.auth.currentUser == null) LoginActivity::class.java else
                runCatching { Repo.role() }.getOrNull().let {
                    when (it) {
                        "admin" -> AdminHomeActivity::class.java
                        "employee" -> EmployeeHomeActivity::class.java
                        else -> { Repo.signOut(); LoginActivity::class.java }
                    }
                }
            startActivity(Intent(this@SplashActivity, target))
            finish()
        }
    }
}
