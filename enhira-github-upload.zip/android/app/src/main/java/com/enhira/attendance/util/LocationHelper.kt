package com.enhira.attendance.util

import android.annotation.SuppressLint
import android.content.Context
import android.location.Location
import android.os.Build
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.tasks.CancellationTokenSource
import kotlinx.coroutines.tasks.await
import kotlin.math.asin
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

data class Fix(val lat: Double, val lng: Double, val accuracyM: Double, val isMock: Boolean, val fixTimeMs: Long) {
    /** Sent to the server, which re-validates everything. The client's opinion is only a hint. */
    fun toMap(): Map<String, Any> = mapOf(
        "lat" to lat, "lng" to lng, "accuracyM" to accuracyM, "isMock" to isMock, "fixTimeMs" to fixTimeMs,
    )
}

object LocationHelper {
    /** Requests a fresh high-accuracy fix (not a cached one). Caller must hold ACCESS_FINE_LOCATION. */
    @SuppressLint("MissingPermission")
    suspend fun freshFix(context: Context): Fix? {
        val client = LocationServices.getFusedLocationProviderClient(context)
        val loc: Location = client
            .getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, CancellationTokenSource().token)
            .await() ?: return null
        val mock = if (Build.VERSION.SDK_INT >= 31) loc.isMock else @Suppress("DEPRECATION") loc.isFromMockProvider
        return Fix(loc.latitude, loc.longitude, loc.accuracy.toDouble(), mock, loc.time)
    }

    /** Informational only (for the on-screen distance); the server's Haversine check is authoritative. */
    fun haversineMeters(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val r = 6371008.8
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = sin(dLat / 2).pow(2) + cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) * sin(dLon / 2).pow(2)
        return 2 * r * asin(min(1.0, sqrt(a)))
    }
}
