package com.enhira.attendance.util

import android.view.View
import android.widget.TextView
import com.enhira.attendance.databinding.ItemStatBinding
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

fun ItemStatBinding.set(label: String, value: String) {
    statLabel.text = label.uppercase(Locale.getDefault())
    statValue.text = value
}

fun View.show(visible: Boolean) { visibility = if (visible) View.VISIBLE else View.GONE }

fun TextView.error(msg: String?) { text = msg; show(!msg.isNullOrEmpty()) }

object Dates {
    fun today(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
    fun time(ms: Long?): String = if (ms == null) "–" else SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date(ms))
    fun hm(minutes: Long?): String = if (minutes == null) "–" else "${minutes / 60}h ${minutes % 60}m"
}
