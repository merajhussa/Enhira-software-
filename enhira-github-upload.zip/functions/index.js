'use strict';
const admin = require('firebase-admin');
const { onCall, HttpsError } = require('firebase-functions/v2/https');
admin.initializeApp();

const C = require('./lib/common');
const { evaluateGeofence, MESSAGES } = require('./lib/geo');
const QR = require('./lib/qr');
const A = require('./lib/attendance');
const { db, FieldValue, Timestamp } = C;

const opts = { region: 'asia-south1', enforceAppCheck: false /* set true once App Check is configured */ };

const QR_MESSAGES = {
  QR_MALFORMED: 'That is not an Enhira office QR code.',
  QR_WRONG_OFFICE: 'This QR code belongs to a different office.',
  QR_INVALID: 'QR code is not valid.',
  QR_EXPIRED: 'QR code has expired. Scan the code currently shown at the office.',
  QR_REQUIRED: 'Scan the office QR code to continue.',
  WIFI_UNAVAILABLE: 'Office Wi-Fi could not be verified on this device.',
  WIFI_MISMATCH: 'You are not connected to the office Wi-Fi.',
};

// ---------- shared verification used by check-in and check-out ----------
async function loadActiveEmployee(uid) {
  const snap = await db().doc(`employees/${uid}`).get();
  if (!snap.exists || snap.data().status !== 'approved') {
    throw new HttpsError('permission-denied', 'Your account is not approved for attendance.');
  }
  return snap.data();
}

async function verifyPresence({ uid, emp, data, settings, nowMs, isCheckOut }) {
  const officeSnap = await db().doc(`officeLocations/${emp.officeId}`).get();
  const o = officeSnap.exists ? officeSnap.data() : null;
  const office = o && o.active !== false ? { lat: o.lat, lng: o.lng, radiusM: o.radiusM } : null;

  const f = data.fix || {};
  const fix = {
    lat: f.lat, lng: f.lng, accuracyM: f.accuracyM, isMock: f.isMock === true,
    fixTimeMs: typeof f.fixTimeMs === 'number' ? f.fixTimeMs : NaN,
  };
  const last = emp.lastFix ? { lat: emp.lastFix.lat, lng: emp.lastFix.lng, atMs: emp.lastFix.atMs } : null;

  const geo = evaluateGeofence({
    office, fix, nowMs, lastFix: last,
    limits: { maxAccuracyM: settings.maxAccuracyM, maxFixAgeMs: settings.maxFixAgeSeconds * 1000, maxSpeedMps: settings.maxSpeedMps },
  });

  const result = { geo, qrOk: false, wifiOk: false, code: geo.code, message: MESSAGES[geo.code] || 'Verification failed.' };
  if (!geo.ok) return result;

  const policy = settings.verificationPolicy;
  const needQr = policy === 'GPS_QR' && (!isCheckOut || settings.requireQrOnCheckOut);
  if (needQr) {
    if (!data.qrToken) return { ...result, code: 'QR_REQUIRED', message: QR_MESSAGES.QR_REQUIRED };
    const secretSnap = await db().doc(`qrTokens/${emp.officeId}`).get();
    if (!secretSnap.exists) return { ...result, code: 'OFFICE_NOT_CONFIGURED', message: MESSAGES.OFFICE_NOT_CONFIGURED };
    const v = QR.verifyToken({
      secret: secretSnap.data().secret, officeId: emp.officeId, token: data.qrToken, nowMs,
      windowMs: settings.qrWindowSeconds * 1000,
    });
    if (!v.ok) return { ...result, code: v.code, message: QR_MESSAGES[v.code], qrFailed: true };
    result.qrOk = true;
  }
  if (policy === 'GPS_WIFI') {
    const bssid = typeof data.wifiBssid === 'string' ? data.wifiBssid.toLowerCase() : '';
    if (!bssid) return { ...result, code: 'WIFI_UNAVAILABLE', message: QR_MESSAGES.WIFI_UNAVAILABLE };
    if (!(settings.allowedBssids || []).map((b) => String(b).toLowerCase()).includes(bssid)) {
      return { ...result, code: 'WIFI_MISMATCH', message: QR_MESSAGES.WIFI_MISMATCH };
    }
    result.wifiOk = true;
  }
  result.code = 'OK';
  result.message = MESSAGES.OK;
  return result;
}

async function recordFailure({ uid, emp, v, kind, nowMs }) {
  const suspicious = v.geo.suspicious || v.qrFailed;
  await C.audit({
    action: `attendance.${kind}.blocked`, actorUid: uid, subjectUid: uid,
    severity: suspicious ? 'suspicious' : 'warning',
    details: { code: v.code, distanceM: v.geo.distanceM, accuracyM: v.geo.accuracyM, flags: v.geo.flags, employeeId: emp.employeeId },
  });
  await db().collection('attendanceEvents').add({
    employeeUid: uid, employeeId: emp.employeeId, type: `${kind}_blocked`, code: v.code,
    suspicious, distanceM: v.geo.distanceM, at: FieldValue.serverTimestamp(),
  });
  await C.notify(uid, 'location_failed', 'Attendance not recorded', v.message);
}

function failureReply(v) {
  return { ok: false, code: v.code, message: v.message, distanceM: v.geo.distanceM, accuracyM: v.geo.accuracyM };
}

function attendanceView(a) {
  const ms = (t) => (t ? t.toMillis() : null);
  return {
    date: a.date, status: a.status, checkInMs: ms(a.checkInAt), checkOutMs: ms(a.checkOutAt),
    workedMinutes: a.workedMinutes ?? null, lateMinutes: a.lateMinutes ?? 0,
    earlyDepartureMinutes: a.earlyDepartureMinutes ?? 0, overtimeMinutes: a.overtimeMinutes ?? 0,
  };
}

async function policyFor(emp, settings) {
  let p = { ...settings.attendancePolicy };
  if (emp.shiftId) {
    const s = await db().doc(`shifts/${emp.shiftId}`).get();
    if (s.exists) {
      const { startMin, endMin, graceMin, breakMin } = s.data();
      p = { ...p, ...Object.fromEntries(Object.entries({ startMin, endMin, graceMin, breakMin }).filter(([, x]) => Number.isFinite(x))) };
    }
  }
  return p;
}

// ---------- check in ----------
exports.checkIn = onCall(opts, async (req) => {
  const uid = C.requireAuth(req);
  const settings = await C.getSettings();
  await C.throttle(uid, 'attendance', settings.throttlePerMinute);
  const emp = await loadActiveEmployee(uid);
  const nowMs = Date.now();
  const policy = await policyFor(emp, settings);
  const date = A.localDateString(nowMs, policy.tzOffsetMin);

  const v = await verifyPresence({ uid, emp, data: req.data || {}, settings, nowMs, isCheckOut: false });
  if (v.code !== 'OK') { await recordFailure({ uid, emp, v, kind: 'checkin', nowMs }); return failureReply(v); }

  const ref = db().doc(`attendance/${uid}_${date}`);
  const out = await db().runTransaction(async (tx) => {
    const s = await tx.get(ref);
    if (s.exists && s.data().checkInAt) return { dup: true, a: s.data() };
    const lateMinutes = A.computeLateMinutes(nowMs, policy);
    const doc = {
      employeeUid: uid, employeeId: emp.employeeId, employeeName: emp.name, departmentId: emp.departmentId || null,
      officeId: emp.officeId, date, status: A.openDayStatus(nowMs, policy), lateMinutes,
      checkInAt: Timestamp.fromMillis(nowMs), // server clock is the source of truth
      checkInLat: req.data.fix.lat, checkInLng: req.data.fix.lng,
      checkInDistanceM: Math.round(v.geo.distanceM * 10) / 10, checkInAccuracyM: v.geo.accuracyM,
      gpsVerified: true, qrVerified: v.qrOk, wifiVerified: v.wifiOk,
      version: 1, corrected: false, createdAt: FieldValue.serverTimestamp(), updatedAt: FieldValue.serverTimestamp(),
    };
    tx.set(ref, doc);
    tx.set(db().doc(`employees/${uid}`), { lastFix: { lat: req.data.fix.lat, lng: req.data.fix.lng, atMs: nowMs } }, { merge: true });
    return { dup: false, a: { ...doc, checkInAt: Timestamp.fromMillis(nowMs) } };
  });

  if (out.dup) {
    await C.audit({ action: 'attendance.checkin.duplicate', actorUid: uid, subjectUid: uid, severity: 'warning', details: { date } });
    return { ok: false, code: 'ALREADY_CHECKED_IN', message: 'You have already checked in today.', attendance: attendanceView(out.a) };
  }
  await db().collection('attendanceEvents').add({
    employeeUid: uid, employeeId: emp.employeeId, type: 'check_in', code: 'OK', suspicious: false,
    distanceM: v.geo.distanceM, accuracyM: v.geo.accuracyM, qrVerified: v.qrOk, at: FieldValue.serverTimestamp(),
  });
  await C.notify(uid, 'check_in', 'Checked in', `Check-in recorded. Distance from office: ${Math.round(v.geo.distanceM)} m.`);
  if (out.a.lateMinutes > 0) await C.notify(uid, 'late_arrival', 'Late arrival', `You were ${out.a.lateMinutes} minutes late today.`);
  return { ok: true, code: 'OK', message: 'Check-in successful.', distanceM: v.geo.distanceM, accuracyM: v.geo.accuracyM, attendance: attendanceView(out.a) };
});

// ---------- check out ----------
exports.checkOut = onCall(opts, async (req) => {
  const uid = C.requireAuth(req);
  const settings = await C.getSettings();
  await C.throttle(uid, 'attendance', settings.throttlePerMinute);
  const emp = await loadActiveEmployee(uid);
  const nowMs = Date.now();
  const policy = await policyFor(emp, settings);
  const date = A.localDateString(nowMs, policy.tzOffsetMin);
  const ref = db().doc(`attendance/${uid}_${date}`);

  const pre = await ref.get();
  if (!pre.exists || !pre.data().checkInAt) {
    await C.audit({ action: 'attendance.checkout.no_checkin', actorUid: uid, subjectUid: uid, severity: 'warning', details: { date } });
    return { ok: false, code: 'NO_CHECKIN', message: 'You have not checked in today.' };
  }
  if (pre.data().checkOutAt) {
    return { ok: false, code: 'ALREADY_CHECKED_OUT', message: 'You have already checked out today.', attendance: attendanceView(pre.data()) };
  }

  const v = await verifyPresence({ uid, emp, data: req.data || {}, settings, nowMs, isCheckOut: true });
  if (v.code !== 'OK') { await recordFailure({ uid, emp, v, kind: 'checkout', nowMs }); return failureReply(v); }

  const out = await db().runTransaction(async (tx) => {
    const s = await tx.get(ref);
    const a = s.data();
    if (a.checkOutAt) return { dup: true, a };
    const checkInMs = a.checkInAt.toMillis();
    if (nowMs <= checkInMs) throw new HttpsError('failed-precondition', 'Invalid check-out time.');
    const day = A.computeDay({ checkInMs, checkOutMs: nowMs, policy });
    const upd = {
      checkOutAt: Timestamp.fromMillis(nowMs), checkOutLat: req.data.fix.lat, checkOutLng: req.data.fix.lng,
      checkOutDistanceM: Math.round(v.geo.distanceM * 10) / 10, checkOutAccuracyM: v.geo.accuracyM,
      checkOutGpsVerified: true, checkOutQrVerified: v.qrOk,
      status: day.status, workedMinutes: day.workedMinutes, lateMinutes: day.lateMinutes,
      earlyDepartureMinutes: day.earlyDepartureMinutes, overtimeMinutes: day.overtimeMinutes,
      version: (a.version || 1) + 1, updatedAt: FieldValue.serverTimestamp(),
    };
    tx.update(ref, upd);
    tx.set(db().doc(`employees/${uid}`), { lastFix: { lat: req.data.fix.lat, lng: req.data.fix.lng, atMs: nowMs } }, { merge: true });
    return { dup: false, a: { ...a, ...upd, checkOutAt: Timestamp.fromMillis(nowMs) } };
  });
  if (out.dup) return { ok: false, code: 'ALREADY_CHECKED_OUT', message: 'You have already checked out today.' };

  await db().collection('attendanceEvents').add({
    employeeUid: uid, employeeId: emp.employeeId, type: 'check_out', code: 'OK', suspicious: false,
    distanceM: v.geo.distanceM, accuracyM: v.geo.accuracyM, qrVerified: v.qrOk, at: FieldValue.serverTimestamp(),
  });
  const h = Math.floor(out.a.workedMinutes / 60), m = out.a.workedMinutes % 60;
  await C.notify(uid, 'check_out', 'Checked out', `Check-out recorded. Worked ${h}h ${m}m today.`);
  return { ok: true, code: 'OK', message: 'Check-out successful.', distanceM: v.geo.distanceM, accuracyM: v.geo.accuracyM, attendance: attendanceView(out.a) };
});

// ---------- rotating office QR (shown on the office kiosk / admin screen) ----------
exports.getOfficeQr = onCall(opts, async (req) => {
  const { uid } = await C.requireAdmin(req, 'qr.display');
  const officeId = C.str(req.data?.officeId, { min: 1, max: 64, name: 'officeId' });
  const settings = await C.getSettings();
  const ref = db().doc(`qrTokens/${officeId}`);
  let snap = await ref.get();
  if (!snap.exists) {
    const office = await db().doc(`officeLocations/${officeId}`).get();
    if (!office.exists) throw new HttpsError('not-found', 'Unknown office.');
    await ref.set({ officeId, secret: QR.generateSecret(), rotatedAt: FieldValue.serverTimestamp() });
    snap = await ref.get();
  }
  const t = QR.issueToken({ secret: snap.data().secret, officeId, nowMs: Date.now(), windowMs: settings.qrWindowSeconds * 1000 });
  return { token: t.token, expiresAtMs: t.expiresAtMs, windowMs: t.windowMs, serverNowMs: Date.now() };
});

/** Rotates the secret, instantly invalidating any leaked/photographed codes. */
exports.rotateOfficeQrSecret = onCall(opts, async (req) => {
  const { uid } = await C.requireAdmin(req, 'settings.manage');
  const officeId = C.str(req.data?.officeId, { min: 1, max: 64, name: 'officeId' });
  await db().doc(`qrTokens/${officeId}`).set({ officeId, secret: QR.generateSecret(), rotatedAt: FieldValue.serverTimestamp() });
  await C.audit({ action: 'qr.secret_rotated', actorUid: uid, details: { officeId } });
  return { ok: true };
});

// ---------- registration & approval ----------
exports.submitRegistration = onCall(opts, async (req) => {
  const uid = C.requireAuth(req);
  const name = C.str(req.data?.name, { min: 2, max: 80, name: 'Name' });
  const phone = C.str(req.data?.phone, { min: 7, max: 20, name: 'Phone' });
  if (!/^[+0-9 ()-]{7,20}$/.test(phone)) throw new HttpsError('invalid-argument', 'Enter a valid phone number.');
  await C.throttle(uid, 'register', 5, 3600);
  const user = await admin.auth().getUser(uid);
  const ref = db().doc(`employees/${uid}`);
  if ((await ref.get()).exists) return { ok: true, status: (await ref.get()).data().status };
  await db().doc(`users/${uid}`).set({ uid, role: 'employee', email: user.email, createdAt: FieldValue.serverTimestamp() });
  await ref.set({ uid, name, phone, email: user.email, status: 'pending', employeeId: null, createdAt: FieldValue.serverTimestamp() });
  await C.audit({ action: 'registration.submitted', actorUid: uid, subjectUid: uid });
  return { ok: true, status: 'pending' };
});

exports.reviewRegistration = onCall(opts, async (req) => {
  const { uid: adminUid } = await C.requireAdmin(req, 'employees.manage');
  const target = C.str(req.data?.uid, { min: 5, max: 128, name: 'uid' });
  const decision = req.data?.decision;
  if (!['approve', 'reject'].includes(decision)) throw new HttpsError('invalid-argument', 'decision must be approve or reject.');
  const ref = db().doc(`employees/${target}`);
  const snap = await ref.get();
  if (!snap.exists || snap.data().status !== 'pending') throw new HttpsError('failed-precondition', 'No pending registration for this user.');

  if (decision === 'reject') {
    const reason = C.str(req.data?.reason ?? 'Not specified', { min: 1, max: 300, name: 'reason' });
    await ref.update({ status: 'rejected', rejectionReason: reason, reviewedBy: adminUid, reviewedAt: FieldValue.serverTimestamp() });
    await C.audit({ action: 'registration.rejected', actorUid: adminUid, subjectUid: target, details: { reason } });
    await C.notify(target, 'registration', 'Registration rejected', reason);
    return { ok: true };
  }

  const authUser = await admin.auth().getUser(target);
  if (!authUser.emailVerified) throw new HttpsError('failed-precondition', 'The employee has not verified their email yet.');
  const d = req.data;
  const employeeId = await db().runTransaction(async (tx) => {
    const cref = db().doc('companySettings/counters');
    const c = await tx.get(cref);
    const next = (c.exists ? c.data().employeeSeq || 0 : 0) + 1;
    tx.set(cref, { employeeSeq: next }, { merge: true });
    return d.employeeId ? C.str(d.employeeId, { min: 3, max: 20, name: 'Employee ID' }) : `ENH-${String(next).padStart(4, '0')}`;
  });
  const dup = await db().collection('employees').where('employeeId', '==', employeeId).limit(1).get();
  if (!dup.empty) throw new HttpsError('already-exists', 'That employee ID is already in use.');

  await ref.update({
    status: 'approved', employeeId,
    departmentId: d.departmentId || null, designationId: d.designationId || null,
    officeId: C.str(d.officeId, { min: 1, max: 64, name: 'Work location' }), shiftId: d.shiftId || null,
    joiningDate: d.joiningDate || null, weeklyOff: Array.isArray(d.weeklyOff) ? d.weeklyOff.slice(0, 7) : ['Sunday'],
    reviewedBy: adminUid, reviewedAt: FieldValue.serverTimestamp(),
  });
  await admin.auth().setCustomUserClaims(target, { role: 'employee' });
  await C.audit({ action: 'registration.approved', actorUid: adminUid, subjectUid: target, details: { employeeId } });
  await C.notify(target, 'registration', 'Registration approved', `Welcome to Enhira. Your employee ID is ${employeeId}.`);
  return { ok: true, employeeId };
});

exports.createAdmin = onCall(opts, async (req) => {
  const { uid: by } = await C.requireAdmin(req, 'admins.manage');
  const email = C.str(req.data?.email, { min: 5, max: 120, name: 'Email' });
  const name = C.str(req.data?.name, { min: 2, max: 80, name: 'Name' });
  const password = C.str(req.data?.password, { min: 10, max: 128, name: 'Password' });
  const role = req.data?.role;
  if (!C.ROLE_PERMS[role]) throw new HttpsError('invalid-argument', 'Unknown admin role.');
  const u = await admin.auth().createUser({ email, password, displayName: name, emailVerified: true });
  await admin.auth().setCustomUserClaims(u.uid, { role: 'admin' });
  await db().doc(`admins/${u.uid}`).set({ uid: u.uid, name, email, adminRole: role, permissions: C.ROLE_PERMS[role], active: true, createdBy: by, createdAt: FieldValue.serverTimestamp() });
  await db().doc(`users/${u.uid}`).set({ uid: u.uid, role: 'admin', email, createdAt: FieldValue.serverTimestamp() });
  await C.audit({ action: 'admin.created', actorUid: by, subjectUid: u.uid, details: { role } });
  return { ok: true, uid: u.uid };
});

// ---------- attendance corrections (never overwrite silently) ----------
const CORRECTABLE = ['checkInMs', 'checkOutMs', 'status'];
const STATUSES = ['Present', 'Absent', 'Half Day', 'Late', 'Early Leave', 'On Leave', 'Holiday', 'Weekly Off', 'Work From Home'];

function sanitizeChanges(ch) {
  const out = {};
  for (const k of CORRECTABLE) if (ch && ch[k] !== undefined) out[k] = ch[k];
  if (!Object.keys(out).length) throw new HttpsError('invalid-argument', 'No changes supplied.');
  if (out.status !== undefined && !STATUSES.includes(out.status)) throw new HttpsError('invalid-argument', 'Unknown status.');
  for (const k of ['checkInMs', 'checkOutMs']) if (out[k] !== undefined && !(Number.isFinite(out[k]) && out[k] > 0)) throw new HttpsError('invalid-argument', `${k} is invalid.`);
  return out;
}

async function applyCorrection({ correctionRef, attendanceRef, changes, actorUid, settings }) {
  return db().runTransaction(async (tx) => {
    const as = await tx.get(attendanceRef);
    if (!as.exists) throw new HttpsError('not-found', 'Attendance record not found.');
    const a = as.data();
    const before = {
      checkInMs: a.checkInAt ? a.checkInAt.toMillis() : null, checkOutMs: a.checkOutAt ? a.checkOutAt.toMillis() : null,
      status: a.status, workedMinutes: a.workedMinutes ?? null, lateMinutes: a.lateMinutes ?? 0,
      earlyDepartureMinutes: a.earlyDepartureMinutes ?? 0, version: a.version || 1,
    };
    const ciMs = changes.checkInMs ?? before.checkInMs;
    const coMs = changes.checkOutMs ?? before.checkOutMs;
    const upd = { corrected: true, version: before.version + 1, updatedAt: FieldValue.serverTimestamp(), lastCorrectionId: correctionRef.id };
    const emp = (await tx.get(db().doc(`employees/${a.employeeUid}`))).data() || {};
    const policy = await policyFor(emp, settings);
    if (changes.checkInMs !== undefined) { upd.checkInAt = Timestamp.fromMillis(changes.checkInMs); }
    if (changes.checkOutMs !== undefined) { upd.checkOutAt = Timestamp.fromMillis(changes.checkOutMs); }
    if (ciMs) upd.lateMinutes = A.computeLateMinutes(ciMs, policy);
    if (ciMs && coMs) {
      if (coMs <= ciMs) throw new HttpsError('invalid-argument', 'Check-out must be after check-in.');
      const day = A.computeDay({ checkInMs: ciMs, checkOutMs: coMs, policy });
      Object.assign(upd, { workedMinutes: day.workedMinutes, earlyDepartureMinutes: day.earlyDepartureMinutes, overtimeMinutes: day.overtimeMinutes, status: day.status });
    }
    if (changes.status !== undefined) upd.status = changes.status; // explicit status wins
    tx.update(attendanceRef, upd);
    const after = { ...before, ...Object.fromEntries(Object.entries({ checkInMs: ciMs, checkOutMs: coMs, status: upd.status ?? before.status, workedMinutes: upd.workedMinutes ?? before.workedMinutes, lateMinutes: upd.lateMinutes ?? before.lateMinutes, earlyDepartureMinutes: upd.earlyDepartureMinutes ?? before.earlyDepartureMinutes }).filter(([, v]) => v !== undefined)), version: before.version + 1 };
    tx.set(correctionRef, { status: 'applied', before, after, appliedBy: actorUid, appliedAt: FieldValue.serverTimestamp() }, { merge: true });
    return { employeeUid: a.employeeUid, date: a.date };
  });
}

exports.correctAttendance = onCall(opts, async (req) => {
  const { uid } = await C.requireAdmin(req, 'attendance.correct');
  const attendanceId = C.str(req.data?.attendanceId, { min: 3, max: 200, name: 'attendanceId' });
  const reason = C.str(req.data?.reason, { min: 8, max: 500, name: 'Reason' });
  const changes = sanitizeChanges(req.data?.changes);
  const settings = await C.getSettings();
  const attendanceRef = db().doc(`attendance/${attendanceId}`);
  const correctionRef = db().collection('attendanceCorrections').doc();
  await correctionRef.set({ attendanceId, changes, reason, requestedBy: uid, requestedByRole: 'admin', status: 'pending', createdAt: FieldValue.serverTimestamp() });
  const r = await applyCorrection({ correctionRef, attendanceRef, changes, actorUid: uid, settings });
  await C.audit({ action: 'attendance.corrected', actorUid: uid, subjectUid: r.employeeUid, details: { attendanceId, correctionId: correctionRef.id, reason } });
  await C.notify(r.employeeUid, 'attendance_correction', 'Attendance corrected', `Your attendance for ${r.date} was corrected. Reason: ${reason}`);
  return { ok: true, correctionId: correctionRef.id };
});

exports.requestCorrection = onCall(opts, async (req) => {
  const uid = C.requireAuth(req);
  await C.throttle(uid, 'correction', 5, 3600);
  const attendanceId = C.str(req.data?.attendanceId, { min: 3, max: 200, name: 'attendanceId' });
  if (!attendanceId.startsWith(`${uid}_`)) throw new HttpsError('permission-denied', 'You can only request corrections for your own attendance.');
  const reason = C.str(req.data?.reason, { min: 8, max: 500, name: 'Reason' });
  const changes = sanitizeChanges(req.data?.changes);
  if (!(await db().doc(`attendance/${attendanceId}`).get()).exists) throw new HttpsError('not-found', 'Attendance record not found.');
  const ref = await db().collection('attendanceCorrections').add({ attendanceId, employeeUid: uid, changes, reason, requestedBy: uid, requestedByRole: 'employee', status: 'pending', createdAt: FieldValue.serverTimestamp() });
  await C.audit({ action: 'attendance.correction_requested', actorUid: uid, subjectUid: uid, details: { attendanceId, correctionId: ref.id } });
  return { ok: true, correctionId: ref.id };
});

exports.reviewCorrection = onCall(opts, async (req) => {
  const { uid } = await C.requireAdmin(req, 'attendance.correct');
  const id = C.str(req.data?.correctionId, { min: 3, max: 128, name: 'correctionId' });
  const decision = req.data?.decision;
  if (!['approve', 'reject'].includes(decision)) throw new HttpsError('invalid-argument', 'decision must be approve or reject.');
  const ref = db().doc(`attendanceCorrections/${id}`);
  const s = await ref.get();
  if (!s.exists || s.data().status !== 'pending') throw new HttpsError('failed-precondition', 'No pending correction with that id.');
  const c = s.data();
  if (decision === 'reject') {
    await ref.update({ status: 'rejected', reviewedBy: uid, reviewedAt: FieldValue.serverTimestamp(), reviewNote: String(req.data?.note || '').slice(0, 300) });
    await C.audit({ action: 'attendance.correction_rejected', actorUid: uid, subjectUid: c.employeeUid, details: { correctionId: id } });
    await C.notify(c.employeeUid, 'attendance_correction', 'Correction request rejected', 'Your attendance correction request was not approved.');
    return { ok: true };
  }
  const settings = await C.getSettings();
  const r = await applyCorrection({ correctionRef: ref, attendanceRef: db().doc(`attendance/${c.attendanceId}`), changes: c.changes, actorUid: uid, settings });
  await C.audit({ action: 'attendance.correction_approved', actorUid: uid, subjectUid: r.employeeUid, details: { correctionId: id } });
  await C.notify(r.employeeUid, 'attendance_correction', 'Correction approved', `Your attendance for ${r.date} was updated.`);
  return { ok: true };
});
