'use strict';
// One-time creation of the first super admin. Run on a trusted machine with
// Application Default Credentials (gcloud auth application-default login) or the emulator.
//   node scripts/bootstrap-admin.js you@company.com "Your Name" "a-strong-password"
// Also seeds the default office, company settings and counters (production-safe, no demo data).
const admin = require('firebase-admin');
admin.initializeApp();
const { ROLE_PERMS } = require('../lib/common');

(async () => {
  const [email, name, password] = process.argv.slice(2);
  if (!email || !name || !password || password.length < 10) {
    console.error('Usage: node scripts/bootstrap-admin.js <email> "<name>" "<password min 10 chars>"');
    process.exit(1);
  }
  const db = admin.firestore();
  const u = await admin.auth().createUser({ email, password, displayName: name, emailVerified: true });
  await admin.auth().setCustomUserClaims(u.uid, { role: 'admin' });
  const now = admin.firestore.FieldValue.serverTimestamp();
  await db.doc(`admins/${u.uid}`).set({ uid: u.uid, name, email, adminRole: 'super_admin', permissions: ROLE_PERMS.super_admin, active: true, createdAt: now });
  await db.doc(`users/${u.uid}`).set({ uid: u.uid, role: 'admin', email, createdAt: now });
  await db.doc('companySettings/main').set({ companyName: 'Enhira', verificationPolicy: 'GPS_QR', requireQrOnCheckOut: true }, { merge: true });
  await db.doc('companySettings/public').set({ companyName: 'Enhira', verificationPolicy: 'GPS_QR', requireQrOnCheckOut: true }, { merge: true });
  await db.doc('officeLocations/hq').set({ name: 'Head Office', lat: null, lng: null, radiusM: 100, active: false, createdAt: now }, { merge: true });
  console.log('Super admin created:', u.uid, '\nSet the office latitude/longitude in Admin > Settings, then activate it.');
})().catch((e) => { console.error(e); process.exit(1); });
