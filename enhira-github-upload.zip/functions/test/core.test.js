'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { haversineMeters, evaluateGeofence } = require('../lib/geo');
const { generateSecret, issueToken, verifyToken } = require('../lib/qr');
const A = require('../lib/attendance');

const OFFICE = { lat: 23.2599, lng: 77.4126, radiusM: 100 };
const NOW = Date.UTC(2026, 9, 30, 4, 30); // 10:00 IST
const fix = (o = {}) => ({ lat: OFFICE.lat, lng: OFFICE.lng, accuracyM: 8, fixTimeMs: NOW - 2000, ...o });
// ~0.001 deg latitude = ~111 m
const metersNorth = (m) => OFFICE.lat + m / 111195;

test('haversine: 1 degree latitude ~ 111.2 km, zero distance is zero', () => {
  assert.ok(Math.abs(haversineMeters(0.5, 10, 1.5, 10) - 111195) < 100);
  assert.equal(haversineMeters(23.2599, 77.4126, 23.2599, 77.4126), 0);
});

test('geofence: inside radius is accepted with distance and accuracy', () => {
  const r = evaluateGeofence({ office: OFFICE, fix: fix({ lat: metersNorth(40) }), nowMs: NOW });
  assert.equal(r.ok, true);
  assert.ok(r.distanceM > 35 && r.distanceM < 45);
  assert.equal(r.accuracyM, 8);
});

test('geofence: outside radius is blocked, not flagged suspicious', () => {
  const r = evaluateGeofence({ office: OFFICE, fix: fix({ lat: metersNorth(300) }), nowMs: NOW });
  assert.equal(r.ok, false);
  assert.equal(r.code, 'OUTSIDE_GEOFENCE');
  assert.equal(r.suspicious, false);
  assert.ok(r.distanceM > 290);
});

test('geofence: mock location is blocked and suspicious', () => {
  const r = evaluateGeofence({ office: OFFICE, fix: fix({ isMock: true }), nowMs: NOW });
  assert.equal(r.code, 'MOCK_LOCATION');
  assert.equal(r.suspicious, true);
});

test('geofence: bad coordinates, null island, NaN are rejected', () => {
  for (const bad of [{ lat: 0, lng: 0 }, { lat: NaN, lng: 1 }, { lat: 91, lng: 0 }, { lat: '23.2', lng: '77.4' }]) {
    const r = evaluateGeofence({ office: OFFICE, fix: fix(bad), nowMs: NOW });
    assert.equal(r.ok, false);
    assert.equal(r.code, 'INVALID_COORDINATES');
    assert.equal(r.suspicious, true);
  }
});

test('geofence: poor accuracy, missing accuracy and stale/future fixes are rejected', () => {
  assert.equal(evaluateGeofence({ office: OFFICE, fix: fix({ accuracyM: 120 }), nowMs: NOW }).code, 'LOW_ACCURACY');
  assert.equal(evaluateGeofence({ office: OFFICE, fix: fix({ accuracyM: undefined }), nowMs: NOW }).code, 'LOW_ACCURACY');
  assert.equal(evaluateGeofence({ office: OFFICE, fix: fix({ fixTimeMs: NOW - 120000 }), nowMs: NOW }).code, 'STALE_FIX');
  assert.equal(evaluateGeofence({ office: OFFICE, fix: fix({ fixTimeMs: NOW + 60000 }), nowMs: NOW }).code, 'STALE_FIX');
});

test('geofence: impossible travel between accepted fixes is flagged', () => {
  const lastFix = { lat: OFFICE.lat + 1, lng: OFFICE.lng, atMs: NOW - 60000 }; // ~111 km in 60 s
  const r = evaluateGeofence({ office: OFFICE, fix: fix(), nowMs: NOW, lastFix });
  assert.equal(r.code, 'IMPOSSIBLE_TRAVEL');
  assert.equal(r.suspicious, true);
  const ok = evaluateGeofence({ office: OFFICE, fix: fix(), nowMs: NOW, lastFix: { ...OFFICE, atMs: NOW - 3600000 } });
  assert.equal(ok.ok, true);
});

test('geofence: unconfigured office is rejected', () => {
  assert.equal(evaluateGeofence({ office: null, fix: fix(), nowMs: NOW }).code, 'OFFICE_NOT_CONFIGURED');
  assert.equal(evaluateGeofence({ office: { ...OFFICE, radiusM: 0 }, fix: fix(), nowMs: NOW }).code, 'OFFICE_NOT_CONFIGURED');
});

test('qr: current and previous window valid; expired, tampered, wrong office, malformed rejected', () => {
  const secret = generateSecret();
  const { token, expiresAtMs } = issueToken({ secret, officeId: 'HQ', nowMs: NOW });
  assert.ok(expiresAtMs > NOW);
  assert.equal(verifyToken({ secret, officeId: 'HQ', token, nowMs: NOW }).ok, true);
  assert.equal(verifyToken({ secret, officeId: 'HQ', token, nowMs: NOW + 30000 }).ok, true); // grace
  assert.equal(verifyToken({ secret, officeId: 'HQ', token, nowMs: NOW + 90000 }).code, 'QR_EXPIRED');
  assert.equal(verifyToken({ secret, officeId: 'BR2', token, nowMs: NOW }).code, 'QR_WRONG_OFFICE');
  const tampered = token.slice(0, -1) + (token.endsWith('a') ? 'b' : 'a');
  assert.equal(verifyToken({ secret, officeId: 'HQ', token: tampered, nowMs: NOW }).code, 'QR_INVALID');
  assert.equal(verifyToken({ secret: generateSecret(), officeId: 'HQ', token, nowMs: NOW }).code, 'QR_INVALID');
  assert.equal(verifyToken({ secret, officeId: 'HQ', token: 'garbage', nowMs: NOW }).code, 'QR_MALFORMED');
  assert.equal(verifyToken({ secret, officeId: 'HQ', token: 123, nowMs: NOW }).code, 'QR_MALFORMED');
  // future window forged with a valid-looking mac for a different window must fail
  const [p, o, w, s] = token.split('.');
  assert.equal(verifyToken({ secret, officeId: 'HQ', token: [p, o, Number(w) + 5, s].join('.'), nowMs: NOW }).code, 'QR_INVALID');
});

// ---- attendance math (IST, 09:30-18:30, grace 10, break 60) ----
const ist = (h, m) => Date.UTC(2026, 9, 30, h, m) - 330 * 60000;

test('attendance: date/time helpers use the policy timezone', () => {
  assert.equal(A.localDateString(ist(0, 5), 330), '2026-10-30');
  assert.equal(A.localMinuteOfDay(ist(9, 30), 330), 570);
});

test('attendance: grace boundary and late minutes', () => {
  assert.equal(A.computeLateMinutes(ist(9, 40)), 0);   // exactly at grace
  assert.equal(A.computeLateMinutes(ist(9, 41)), 11);  // counted from start
  assert.equal(A.openDayStatus(ist(9, 29)), 'Present');
  assert.equal(A.openDayStatus(ist(10, 15)), 'Late');
});

test('attendance: full day, overtime, late, early leave, half day, absent', () => {
  let d = A.computeDay({ checkInMs: ist(9, 30), checkOutMs: ist(18, 30) });
  assert.deepEqual([d.status, d.workedMinutes, d.overtimeMinutes], ['Present', 480, 0]);
  d = A.computeDay({ checkInMs: ist(9, 30), checkOutMs: ist(20, 30) });
  assert.deepEqual([d.status, d.overtimeMinutes], ['Present', 120]);
  d = A.computeDay({ checkInMs: ist(10, 0), checkOutMs: ist(19, 0) });
  assert.deepEqual([d.status, d.lateMinutes], ['Late', 30]);
  d = A.computeDay({ checkInMs: ist(9, 30), checkOutMs: ist(17, 45) });
  assert.deepEqual([d.status, d.earlyDepartureMinutes], ['Early Leave', 45]);
  d = A.computeDay({ checkInMs: ist(9, 30), checkOutMs: ist(15, 0) });
  assert.equal(d.status, 'Half Day');
  d = A.computeDay({ checkInMs: ist(9, 30), checkOutMs: ist(12, 0) });
  assert.equal(d.status, 'Absent');
});

test('attendance: policy overrides are honoured and bad ranges throw', () => {
  const d = A.computeDay({ checkInMs: ist(9, 30), checkOutMs: ist(15, 0), policy: { fullDayMinMinutes: 4 * 60 } });
  assert.equal(d.status, 'Early Leave');
  assert.throws(() => A.computeDay({ checkInMs: ist(10, 0), checkOutMs: ist(9, 0) }));
});
